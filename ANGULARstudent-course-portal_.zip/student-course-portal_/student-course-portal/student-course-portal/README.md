# Student Course Portal — Digital Nurture 5.0 Angular Hands-On (1–10)

This is one project covering all 10 hands-ons from the exercise book. Every concept
(components, binding, directives, pipes, forms, services, routing, guards, HTTP,
interceptors, NgRx, unit tests) is wired together in a single working app, with
comments in the code marking which Hands-On / Task / Step each block satisfies.

## 1. One-time setup

```bash
# unzip the project, then from inside the folder:
npm install --legacy-peer-deps
```

(`--legacy-peer-deps` avoids an NgRx/Angular peer-version nag; safe to omit if it installs cleanly.)

## 2. Run the mock backend (needed for Hands-On 8 & 9 — HTTP + NgRx effects)

In one terminal:
```bash
npm run mock-api
# -> json-server --watch db.json --port 3000
```
This serves `http://localhost:3000/courses`, `/students`, `/enrollments` from `db.json`.

## 3. Run the app

In a second terminal:
```bash
npm start
# -> ng serve, open http://localhost:4200
```

## 4. Run unit tests (Hands-On 10)

```bash
npm test
# -> ng test (Karma + Jasmine, watch mode). Ctrl+C to stop.
```

## 5. Where each Hands-On lives

| Hands-On | Where to look |
|---|---|
| 1 — Setup, first component | `angular.json`, `notes.txt`, `src/app/components/header/` |
| 2 — Binding, lifecycle, @Input/@Output | `pages/home/`, `components/course-card/` (`ngOnChanges`), `pages/course-list/` (`@Output`) |
| 3 — Directives & pipes | `directives/highlight.directive.ts`, `pipes/credit-label.pipe.ts`, `components/course-card/` |
| 4 — Template-driven forms | `pages/enrollment-form/` (route `/enroll`) |
| 5 — Reactive forms | `pages/reactive-enrollment-form/` (route `/enroll-reactive`) |
| 6 — Services & DI | `services/course.service.ts`, `services/enrollment.service.ts` |
| 7 — Routing, guards, lazy loading | `app.routes.ts`, `guards/auth.guard.ts`, `guards/unsaved-changes.guard.ts` |
| 8 — HttpClient, RxJS, interceptors | `services/course.service.ts`, `interceptors/*.ts` |
| 9 — NgRx | `store/course/`, `store/enrollment/` |
| 10 — Unit tests | `**/*.spec.ts` (course-card, course.service, course-list w/ MockStore) |

## 6. Quick manual verification checklist

- Home page (`/`) shows live course count pulled from the service, search box updates live.
- `/courses`: loading message → cards render (from NgRx store), hover highlights cards, badges
  show grade status colour, Enroll/Unenroll toggles and updates the store.
- Click a card → navigates to `/courses/:id` and shows that course's detail.
- `/profile` (guarded — redirects home if `AuthService.isLoggedIn` is set to `false`) shows
  enrolled courses.
- `/enroll`: template-driven form — touch a field and leave it empty to see validation errors;
  submit only enabled once valid.
- `/enroll-reactive`: reactive form — try a Course ID starting with `XX` (custom validator),
  try an email containing `test@` (async validator, ~800ms delay), add/remove extra course rows.
  Navigate away while dirty to see the CanDeactivate confirm dialog.
- DevTools → Network: Authorization header present on API calls (auth interceptor); a JS chunk
  loads only the first time you visit `/enroll` (lazy loading).
- DevTools → Redux DevTools: `[Course] Load Courses` → `... Success` action flow on `/courses`.

## 7. Notes / known simplifications

- Angular 20 standalone APIs are used throughout — no NgModules, per the CLI's modern default.
- `AuthService.isLoggedIn` is hardcoded `true` for convenience; flip it to `false` to test the guard redirect.
- The exercise book's Hands-On 7 "nested routes under /courses" (Step 72, `CoursesLayoutComponent`)
  was intentionally left out of the merged routing table to avoid double-defining `/courses` — the
  flat routes already satisfy params + query params + guards + lazy loading. Add the nested layout
  yourself if your evaluator specifically checks for it (the hint in the book explains the pattern).
