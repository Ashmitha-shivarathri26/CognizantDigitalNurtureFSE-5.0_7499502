import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { CourseListComponent } from './course-list.component';
import { selectAllCourses, selectCoursesLoading } from '../../store/course/course.selectors';
import { Course } from '../../models/course.model';

// Hands-On 10, Task 2: testing an NgRx store-connected component with MockStore
describe('CourseListComponent (NgRx)', () => {
  let fixture: ComponentFixture<CourseListComponent>;
  let store: MockStore;

  const mockCourses: Course[] = [
    { id: 1, name: 'Data Structures', code: 'CS101', credits: 4, gradeStatus: 'passed' },
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CourseListComponent, RouterTestingModule],
      providers: [
        provideMockStore({
          initialState: { course: { courses: mockCourses, loading: false, error: null } },
        }),
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(CourseListComponent);
    store = TestBed.inject(MockStore);
  });

  it('should render course cards for the initial state', () => {
    fixture.detectChanges();
    const cards = fixture.debugElement.queryAll(By.css('app-course-card'));
    expect(cards.length).toBe(1);
  });

  it('should show a loading indicator when loading is true', () => {
    store.overrideSelector(selectCoursesLoading, true);
    store.overrideSelector(selectAllCourses, []);
    store.refreshState();
    fixture.detectChanges();

    const loadingText = fixture.debugElement.nativeElement.textContent;
    expect(loadingText).toContain('Loading courses');
  });
});
