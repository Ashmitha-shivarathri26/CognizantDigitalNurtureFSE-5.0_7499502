import { Injectable } from '@angular/core';

// Hands-On 7, Task 2, Step 75: simple hardcoded auth for the guard to check
@Injectable({ providedIn: 'root' })
export class AuthService {
  isLoggedIn = true; // toggle to false to test the auth guard redirect
}
