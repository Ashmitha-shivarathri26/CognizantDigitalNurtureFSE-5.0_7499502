import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, combineLatest, map } from 'rxjs';
import { CourseService } from './course.service';
import { Course } from '../models/course.model';

// Hands-On 6, Task 2: EnrollmentService demonstrates service-to-service injection
@Injectable({ providedIn: 'root' })
export class EnrollmentService {
  private enrolledCourseIds: number[] = [];
  private enrolledIdsSubject = new BehaviorSubject<number[]>([]);
  enrolledIds$ = this.enrolledIdsSubject.asObservable();

  constructor(private courseService: CourseService) {}

  enroll(courseId: number): void {
    if (!this.enrolledCourseIds.includes(courseId)) {
      this.enrolledCourseIds = [...this.enrolledCourseIds, courseId];
      this.enrolledIdsSubject.next(this.enrolledCourseIds);
    }
  }

  unenroll(courseId: number): void {
    this.enrolledCourseIds = this.enrolledCourseIds.filter((id) => id !== courseId);
    this.enrolledIdsSubject.next(this.enrolledCourseIds);
  }

  isEnrolled(courseId: number): boolean {
    return this.enrolledCourseIds.includes(courseId);
  }

  // Combines the live course list with the enrolled-id list, re-deriving
  // whenever either source emits (Step 87 concept applied cleanly with combineLatest)
  getEnrolledCourses(): Observable<Course[]> {
    return combineLatest([this.courseService.getCourses(), this.enrolledIds$]).pipe(
      map(([courses, ids]) => courses.filter((c) => ids.includes(c.id)))
    );
  }
}
