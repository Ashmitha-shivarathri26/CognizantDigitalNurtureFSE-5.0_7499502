import { createReducer, on } from '@ngrx/store';
import { enrollInCourse, unenrollFromCourse } from './enrollment.actions';

// Hands-On 9, Task 2, Step 99
export interface EnrollmentState {
  enrolledCourseIds: number[];
}

export const initialState: EnrollmentState = { enrolledCourseIds: [] };

export const enrollmentReducer = createReducer(
  initialState,
  on(enrollInCourse, (state, { courseId }) => ({
    ...state,
    enrolledCourseIds: state.enrolledCourseIds.includes(courseId)
      ? state.enrolledCourseIds
      : [...state.enrolledCourseIds, courseId],
  })),
  on(unenrollFromCourse, (state, { courseId }) => ({
    ...state,
    enrolledCourseIds: state.enrolledCourseIds.filter((id) => id !== courseId),
  }))
);
