import office from "./image/office.jpg";

function App() {

  const officeSpaces = [
    {
      Name: "DBS",
      Rent: 50000,
      Address: "Chennai",
      Image: office
    },
    {
      Name: "Regus",
      Rent: 65000,
      Address: "Bangalore",
      Image: office
    },
    {
      Name: "WeWork",
      Rent: 55000,
      Address: "Hyderabad",
      Image: office
    }
  ];

  return (
    <div style={{ textAlign: "center" }}>

      <h1>Office Space , at Affordable Range</h1>

      {officeSpaces.map((item, index) => (

        <div key={index} style={{ marginBottom: "30px" }}>

          <img
            src={item.Image}
            alt="Office Space"
            width="250"
            height="250"
          />

          <h2>Name: {item.Name}</h2>

          <h3
            style={{
              color: item.Rent <= 60000 ? "red" : "green"
            }}
          >
            Rent: Rs. {item.Rent}
          </h3>

          <h3>Address: {item.Address}</h3>

        </div>

      ))}

    </div>
  );
}

export default App;