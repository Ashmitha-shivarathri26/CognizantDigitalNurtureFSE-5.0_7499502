import { useState } from "react";

function CurrencyConvertor() {

    const [rupees, setRupees] = useState("");
    const [euro, setEuro] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();

        const result = (parseFloat(rupees) / 109).toFixed(2);
        setEuro(result);
    };

    return (
        <div>
            <h2 style={{ color: "green" }}>Currency Convertor!!!</h2>

            <form onSubmit={handleSubmit}>

                <div>
                    <label>Amount: </label>
                    <input
                        type="number"
                        value={rupees}
                        onChange={(e) => setRupees(e.target.value)}
                    />
                </div>

                <br />

                <div>
                    <label>Currency: </label>
                    <input
                        type="text"
                        value={euro}
                        readOnly
                    />
                </div>

                <br />

                <button type="submit">Submit</button>

            </form>
        </div>
    );
}

export default CurrencyConvertor;