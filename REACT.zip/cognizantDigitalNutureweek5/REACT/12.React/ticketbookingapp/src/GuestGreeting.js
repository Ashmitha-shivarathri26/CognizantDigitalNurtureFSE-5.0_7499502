function GuestGreeting() {
  return (
    <div>
      <h2>Please Sign Up</h2>
      <p>Login to access the Ticket Booking Application.</p>
    </div>
  );
}

export default GuestGreeting;