function UserGreeting() {
  return (
    <div>
      <h2>Welcome Back!</h2>
      <p>You have successfully logged in.</p>
    </div>
  );
}

export default UserGreeting;