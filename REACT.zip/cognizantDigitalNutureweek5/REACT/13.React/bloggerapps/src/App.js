import { useState } from "react";
import BookDetails from "./components/BookDetails";
import BlogDetails from "./components/BlogDetails";
import CourseDetails from "./components/CourseDetails";
import "./App.css";

function App() {

  const [activeSection, setActiveSection] = useState("books");

  return (
    <div className="container">

      <h1>Blogger Application</h1>

      <div className="buttons">
        <button onClick={() => setActiveSection("books")}>
          Books
        </button>

        <button onClick={() => setActiveSection("blogs")}>
          Blogs
        </button>

        <button onClick={() => setActiveSection("courses")}>
          Courses
        </button>
      </div>

      <hr />

      {activeSection === "books" && <BookDetails />}
      {activeSection === "blogs" && <BlogDetails />}
      {activeSection === "courses" && <CourseDetails />}

    </div>
  );
}

export default App;