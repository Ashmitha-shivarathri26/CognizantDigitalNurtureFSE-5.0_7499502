import { blogs } from "../data";

function BlogDetails() {

  const renderBlogs = () => {
    return blogs.map((blog) => (
      <div key={blog.id} style={{ marginBottom: "20px" }}>
        <h3>{blog.title}</h3>

        <p>
          <strong>Author:</strong> {blog.author}
        </p>

        <p>{blog.content}</p>

        <a href="/">Read More</a>

        <hr />
      </div>
    ));
  };

  return (
    <div>
      <h2>Blog Details</h2>
      {renderBlogs()}
    </div>
  );
}

export default BlogDetails;