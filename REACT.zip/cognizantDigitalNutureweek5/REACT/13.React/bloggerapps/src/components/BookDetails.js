import { books } from "../data";

function BookDetails() {

  const renderBooks = () => {
    return books.map((book) => (
      <div key={book.id} style={{ marginBottom: "20px" }}>
        <h3>{book.name}</h3>

        <p>
          <strong>Price:</strong> ₹{book.price}
        </p>

        <p>
          Status:{" "}
          {book.price <= 700 ? (
            <span style={{ color: "green" }}>Affordable</span>
          ) : (
            <span style={{ color: "red" }}>Premium</span>
          )}
        </p>
      </div>
    ));
  };

  return (
    <div>
      <h2>Book Details</h2>
      {renderBooks()}
    </div>
  );
}

export default BookDetails;