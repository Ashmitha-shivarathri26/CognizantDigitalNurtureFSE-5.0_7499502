import { courses } from "../data";

function CourseDetails() {

  const renderCourses = () => {
    return courses.map((course) => (
      <div key={course.id} style={{ marginBottom: "20px" }}>

        <h3>{course.name}</h3>

        <p>
          <strong>Start Date:</strong> {course.date}
        </p>

        <p>
          <strong>Status:</strong>{" "}
          {course.completed ? (
            <span style={{ color: "green" }}>Completed ✅</span>
          ) : (
            <span style={{ color: "orange" }}>In Progress ⏳</span>
          )}
        </p>

        <hr />

      </div>
    ));
  };

  return (
    <div>
      <h2>Course Details</h2>
      {renderCourses()}
    </div>
  );
}

export default CourseDetails;