export const books = [
  {
    id: 101,
    name: "Master React",
    price: 670
  },
  {
    id: 102,
    name: "Deep Dive into Angular 11",
    price: 800
  },
  {
    id: 103,
    name: "Mongo Essentials",
    price: 450
  }
];

export const blogs = [
  {
    id: 1,
    title: "React Learning",
    author: "Stephen Biz",
    content: "Welcome to learning React!"
  },
  {
    id: 2,
    title: "Installation",
    author: "Schwzenedier",
    content: "You can install React using npm."
  }
];

export const courses = [
  {
    id: 1,
    name: "Angular",
    date: "04/05/2021",
    completed: true
  },
  {
    id: 2,
    name: "React",
    date: "06/03/2021",
    completed: false
  }
];