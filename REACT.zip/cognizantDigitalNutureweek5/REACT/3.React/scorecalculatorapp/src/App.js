import { CalculateScore } from './Components/CalculateScore';

function App() {
  return (
    <div>
      <CalculateScore
        name="Shiva"
        school="NTR Vidya School"
        total={720}
        goal={800}
      />
    </div>
  );
}

export default App;