import '../Stylesheets/mystyle.css';

const percentToDecimal = (decimal) => {
    return (decimal * 100) + "%";
}

const calcScore = (total, goal) => {
    return percentToDecimal(total / goal);
}

export const CalculateScore = ({ name, school, total, goal }) => (
    <div className="formatstyle">
        <h1><font color="Brown">Student Details:</font></h1>

        <div className="Name">
            <b>Name:</b>
            <span>{name}</span>
        </div>

        <div className="School">
            <b>School:</b>
            <span>{school}</span>
        </div>

        <div className="Total">
            <b>Total:</b>
            <span>{total}</span>
        </div>

        <div className="Score">
            <b>Score:</b>
            <span>{calcScore(total, goal)}</span>
        </div>
    </div>
);