import React from "react";

function ListofPlayers() {

    const players = [
        { name: "Sachin", score: 90 },
        { name: "Dhoni", score: 85 },
        { name: "Virat", score: 75 },
        { name: "Rohit", score: 65 },
        { name: "Rahul", score: 55 },
        { name: "Hardik", score: 80 },
        { name: "Jadeja", score: 68 },
        { name: "Bumrah", score: 72 },
        { name: "Shami", score: 60 },
        { name: "Ashwin", score: 50 },
        { name: "Gill", score: 95 }
    ];

    const below70 = players.filter(player => player.score < 70);

    return (
        <div>
            <h2>List of Players</h2>

            <h3>All Players</h3>
            <ul>
                {players.map((player, index) => (
                    <li key={index}>
                        {player.name} - {player.score}
                    </li>
                ))}
            </ul>

            <h3>Players with Score Below 70</h3>
            <ul>
                {below70.map((player, index) => (
                    <li key={index}>
                        {player.name} - {player.score}
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default ListofPlayers;