class Product {
    int productId;
    String productName;
    String category;

    Product(int productId, String productName, String category) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
    }
}

public class ECommerceSearch {

    public static void linearSearch(Product[] products, String searchName) {

        boolean found = false;

        for (int i = 0; i < products.length; i++) {

            if (products[i].productName.equalsIgnoreCase(searchName)) {

                System.out.println("Product Found!");
                System.out.println("Product ID: " + products[i].productId);
                System.out.println("Product Name: " + products[i].productName);
                System.out.println("Category: " + products[i].category);

                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Product Not Found");
        }
    }

    public static void binarySearch(Product[] products, String searchName) {

        int left = 0;
        int right = products.length - 1;
        boolean found = false;

        while (left <= right) {

            int mid = (left + right) / 2;

            int result = products[mid].productName.compareToIgnoreCase(searchName);

            if (result == 0) {

                System.out.println("Product Found!");
                System.out.println("Product ID: " + products[mid].productId);
                System.out.println("Product Name: " + products[mid].productName);
                System.out.println("Category: " + products[mid].category);

                found = true;
                break;
            }

            if (result < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        if (!found) {
            System.out.println("Product Not Found");
        }
    }

    public static void main(String[] args) {

        Product[] products = {
                new Product(101, "Laptop", "Electronics"),
                new Product(102, "Mobile", "Electronics"),
                new Product(103, "Shoes", "Fashion"),
                new Product(104, "Tablet", "Electronics"),
                new Product(105, "Watch", "Accessories")
        };

        System.out.println("===== Linear Search =====");
        linearSearch(products, "Shoes");

        Product[] sortedProducts = {
                new Product(101, "Laptop", "Electronics"),
                new Product(102, "Mobile", "Electronics"),
                new Product(103, "Shoes", "Fashion"),
                new Product(104, "Tablet", "Electronics"),
                new Product(105, "Watch", "Accessories")
        };

        System.out.println("\n===== Binary Search =====");
        binarySearch(sortedProducts, "Shoes");
    }
}