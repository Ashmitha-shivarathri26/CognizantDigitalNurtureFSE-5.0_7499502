CREATE DATABASE BankDB;
USE BankDB;
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    CustomerName VARCHAR(50),
    Age INT,
    Balance DECIMAL(10,2),
    IsVIP BOOLEAN DEFAULT FALSE
);

CREATE TABLE Loans (
    LoanID INT PRIMARY KEY,
    CustomerID INT,
    InterestRate DECIMAL(5,2),
    DueDate DATE
);
INSERT INTO Customers VALUES
(1,'Ravi',65,15000,FALSE),
(2,'Priya',45,8000,FALSE),
(3,'Arjun',70,20000,FALSE);

INSERT INTO Loans VALUES
(101,1,8.5,CURDATE()+INTERVAL 20 DAY),
(102,2,9.0,CURDATE()+INTERVAL 40 DAY),
(103,3,7.5,CURDATE()+INTERVAL 15 DAY);
SELECT * FROM Customers;
SELECT * FROM Loans;
SET SQL_SAFE_UPDATES = 0;
UPDATE Loans l
JOIN Customers c
ON l.CustomerID = c.CustomerID
SET l.InterestRate = l.InterestRate - 1
WHERE c.Age > 60;

UPDATE Customers
SET IsVIP = TRUE
WHERE Balance > 10000;

SELECT
c.CustomerName,
l.DueDate,
CONCAT('Reminder: Loan due for ', c.CustomerName) AS Reminder
FROM Customers c
JOIN Loans l
ON c.CustomerID = l.CustomerID
WHERE l.DueDate BETWEEN CURDATE()
AND CURDATE() + INTERVAL 30 DAY;