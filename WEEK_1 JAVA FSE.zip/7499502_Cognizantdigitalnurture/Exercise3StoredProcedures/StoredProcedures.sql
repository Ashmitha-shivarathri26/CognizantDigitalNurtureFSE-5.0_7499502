
USE BankDB;
CREATE TABLE Accounts (
    AccountID INT PRIMARY KEY,
    CustomerID INT,
    AccountType VARCHAR(20),
    Balance DECIMAL(10,2)
);
INSERT INTO Accounts VALUES
(201,1,'Savings',10000),
(202,2,'Savings',8000),
(203,3,'Savings',15000);
SELECT * FROM Accounts;
DELIMITER //

CREATE PROCEDURE ProcessMonthlyInterest()
BEGIN
    UPDATE Accounts
    SET Balance = Balance + (Balance * 0.01)
    WHERE AccountType = 'Savings';
END //
SET SQL_SAFE_UPDATES = 0;
DELIMITER ;
CALL ProcessMonthlyInterest();