import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AAAPatternTest {

    int num1;
    int num2;

    @BeforeEach
    void setUp() {
        System.out.println("Setup method executed");
        num1 = 10;
        num2 = 20;
    }

    @Test
    void testAddition() {

        // Arrange
        int expected = 30;

        // Act
        int result = num1 + num2;

        // Assert
        assertEquals(expected, result);
    }

    @AfterEach
    void tearDown() {
        System.out.println("Teardown method executed");
    }
}